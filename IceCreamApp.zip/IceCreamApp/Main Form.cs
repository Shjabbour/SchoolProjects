﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IceCreamApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            try
            {
                /* This code will receive input of scoops and unit price to calculate cost and other variables,
                output results.*/

                //Declare variables and constant

                int scoops;
                double unitPrice, cost, taxAmount, totalAmount;
                const double taxRate = 0.055;

                //Get our inputes
                int.TryParse(scoopsTextBox.Text, out scoops);
                double.TryParse(unitPriceTextBox.Text, out unitPrice);

                //Perform calculations
                cost = scoops * unitPrice;
                taxAmount = cost * taxRate;
                totalAmount = cost + taxAmount;

                //Output the results
                costLabel.Text = cost.ToString("C2");
                displayListBox.Items.Add("Subtotal:" + cost.ToString("C2"));
                displayListBox.Items.Add("Tax:" + taxAmount.ToString("C2"));
                displayListBox.Items.Add(" ");
                displayListBox.Items.Add("Total:" + totalAmount.ToString("C2"));
            }
            catch (Exception err)
            {
                //Issue an error message and reset focus
                MessageBox.Show(err.Message, "Error Message");
                scoopsTextBox.Focus();

            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //This code will reset the user interface
            scoopsTextBox.Clear();
            unitPriceTextBox.Clear();
            costLabel.Text = null;
            displayListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // ask user for confirmation if they want to exit and if yes, exit the application
            DialogResult dialog = MessageBox.Show("Do you really want to hurt me?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //If the answer is yes, close the app
            if (dialog == DialogResult.Yes)
                this.Close();
        }
    }
}
