﻿
namespace Project_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button30);
            this.panel1.Controls.Add(this.button29);
            this.panel1.Controls.Add(this.button28);
            this.panel1.Controls.Add(this.button27);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.button25);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Controls.Add(this.button23);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.button21);
            this.panel1.Controls.Add(this.button20);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.button16);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.listBox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(25, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1039, 1043);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 31.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(681, 143);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calculator App";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(3, 450);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(681, 593);
            this.label2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Location = new System.Drawing.Point(690, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(346, 1043);
            this.label3.TabIndex = 2;
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 32;
            this.listBox.Location = new System.Drawing.Point(3, 146);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(681, 292);
            this.listBox.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(23, 476);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(195, 92);
            this.button2.TabIndex = 5;
            this.button2.Text = "x^y";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(25, 585);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(193, 92);
            this.button3.TabIndex = 6;
            this.button3.Text = "x!";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(467, 476);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(191, 92);
            this.button4.TabIndex = 7;
            this.button4.Text = "x+y";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(245, 585);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(191, 92);
            this.button6.TabIndex = 9;
            this.button6.Text = "1/x";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(245, 476);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(191, 92);
            this.button7.TabIndex = 10;
            this.button7.Text = "x/y";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(467, 585);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(191, 92);
            this.button8.TabIndex = 11;
            this.button8.Text = "x-y";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(467, 701);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(191, 92);
            this.button5.TabIndex = 12;
            this.button5.Text = "Multiplication Table of x";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(245, 701);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(191, 92);
            this.button9.TabIndex = 13;
            this.button9.Text = "Standard Deviation of x.y";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 701);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 92);
            this.button1.TabIndex = 14;
            this.button1.Text = "Prime";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(467, 816);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(191, 92);
            this.button10.TabIndex = 15;
            this.button10.Text = "Sum of File Values";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(245, 816);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(191, 92);
            this.button11.TabIndex = 16;
            this.button11.Text = "Max of File Values";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(25, 816);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(193, 92);
            this.button12.TabIndex = 17;
            this.button12.Text = "Sum of Squares";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(467, 933);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(191, 92);
            this.button13.TabIndex = 18;
            this.button13.Text = "File Array Value at (x.y)";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(245, 933);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(191, 92);
            this.button14.TabIndex = 19;
            this.button14.Text = "Average of File Values";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(25, 933);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(193, 92);
            this.button15.TabIndex = 20;
            this.button15.Text = "Range of File Values";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button16.Location = new System.Drawing.Point(722, 146);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(82, 61);
            this.button16.TabIndex = 21;
            this.button16.Text = "7";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button17.Location = new System.Drawing.Point(819, 146);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(82, 61);
            this.button17.TabIndex = 22;
            this.button17.Text = "8";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button18.Location = new System.Drawing.Point(916, 146);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(82, 61);
            this.button18.TabIndex = 23;
            this.button18.Text = "9";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button19.Location = new System.Drawing.Point(722, 224);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(82, 61);
            this.button19.TabIndex = 24;
            this.button19.Text = "4";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button20.Location = new System.Drawing.Point(722, 301);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(82, 61);
            this.button20.TabIndex = 25;
            this.button20.Text = "1";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.DarkRed;
            this.button21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button21.Location = new System.Drawing.Point(722, 377);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(82, 61);
            this.button21.TabIndex = 26;
            this.button21.Text = "C";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button22.Location = new System.Drawing.Point(819, 224);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(82, 61);
            this.button22.TabIndex = 27;
            this.button22.Text = "5";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button23.Location = new System.Drawing.Point(819, 301);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(82, 61);
            this.button23.TabIndex = 28;
            this.button23.Text = "2";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button24.Location = new System.Drawing.Point(819, 377);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(82, 61);
            this.button24.TabIndex = 29;
            this.button24.Text = "0";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button25.Location = new System.Drawing.Point(916, 224);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(82, 61);
            this.button25.TabIndex = 30;
            this.button25.Text = "6";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button26.Location = new System.Drawing.Point(916, 301);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(82, 61);
            this.button26.TabIndex = 31;
            this.button26.Text = "3";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.DarkRed;
            this.button27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button27.Location = new System.Drawing.Point(916, 377);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(82, 61);
            this.button27.TabIndex = 32;
            this.button27.Text = "CE";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(711, 727);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(310, 85);
            this.button28.TabIndex = 33;
            this.button28.Text = "&Display File";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(711, 832);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(310, 85);
            this.button29.TabIndex = 34;
            this.button29.Text = "C&lear Results";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(711, 940);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(310, 85);
            this.button30.TabIndex = 35;
            this.button30.Text = "E&xit";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(794, 506);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(227, 48);
            this.label6.TabIndex = 38;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(711, 580);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(28, 27);
            this.checkBox1.TabIndex = 41;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Location = new System.Drawing.Point(746, 575);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 32);
            this.label4.TabIndex = 43;
            this.label4.Text = "y:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.Location = new System.Drawing.Point(746, 522);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 32);
            this.label5.TabIndex = 44;
            this.label5.Text = "x:";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(794, 565);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(227, 48);
            this.label8.TabIndex = 45;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 1106);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

