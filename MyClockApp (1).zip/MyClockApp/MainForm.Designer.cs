﻿
namespace MyClockApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.topLabel = new System.Windows.Forms.Label();
            this.topRightLabel = new System.Windows.Forms.Label();
            this.botLabel = new System.Windows.Forms.Label();
            this.midLabel = new System.Windows.Forms.Label();
            this.botRightLabel = new System.Windows.Forms.Label();
            this.botLeftLabel = new System.Windows.Forms.Label();
            this.topLeftLabel = new System.Windows.Forms.Label();
            this.zeroButton = new System.Windows.Forms.Button();
            this.oneButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.sevenButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.nineButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // topLabel
            // 
            this.topLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.topLabel.Location = new System.Drawing.Point(353, 75);
            this.topLabel.Name = "topLabel";
            this.topLabel.Size = new System.Drawing.Size(423, 89);
            this.topLabel.TabIndex = 0;
            this.topLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // topRightLabel
            // 
            this.topRightLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.topRightLabel.Location = new System.Drawing.Point(773, 164);
            this.topRightLabel.Name = "topRightLabel";
            this.topRightLabel.Size = new System.Drawing.Size(122, 238);
            this.topRightLabel.TabIndex = 1;
            // 
            // botLabel
            // 
            this.botLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.botLabel.Location = new System.Drawing.Point(353, 729);
            this.botLabel.Name = "botLabel";
            this.botLabel.Size = new System.Drawing.Size(423, 89);
            this.botLabel.TabIndex = 2;
            // 
            // midLabel
            // 
            this.midLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.midLabel.Location = new System.Drawing.Point(353, 402);
            this.midLabel.Name = "midLabel";
            this.midLabel.Size = new System.Drawing.Size(423, 89);
            this.midLabel.TabIndex = 3;
            this.midLabel.Click += new System.EventHandler(this.midLabel_Click);
            // 
            // botRightLabel
            // 
            this.botRightLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.botRightLabel.Location = new System.Drawing.Point(773, 491);
            this.botRightLabel.Name = "botRightLabel";
            this.botRightLabel.Size = new System.Drawing.Size(122, 238);
            this.botRightLabel.TabIndex = 5;
            // 
            // botLeftLabel
            // 
            this.botLeftLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.botLeftLabel.Location = new System.Drawing.Point(234, 491);
            this.botLeftLabel.Name = "botLeftLabel";
            this.botLeftLabel.Size = new System.Drawing.Size(122, 238);
            this.botLeftLabel.TabIndex = 6;
            // 
            // topLeftLabel
            // 
            this.topLeftLabel.BackColor = System.Drawing.Color.DarkGreen;
            this.topLeftLabel.Location = new System.Drawing.Point(234, 164);
            this.topLeftLabel.Name = "topLeftLabel";
            this.topLeftLabel.Size = new System.Drawing.Size(122, 238);
            this.topLeftLabel.TabIndex = 7;
            // 
            // zeroButton
            // 
            this.zeroButton.Location = new System.Drawing.Point(1029, 21);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(237, 129);
            this.zeroButton.TabIndex = 8;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = true;
            this.zeroButton.Click += new System.EventHandler(this.zeroButton_Click);
            // 
            // oneButton
            // 
            this.oneButton.Location = new System.Drawing.Point(1280, 21);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(237, 129);
            this.oneButton.TabIndex = 9;
            this.oneButton.Text = "1";
            this.oneButton.UseVisualStyleBackColor = true;
            this.oneButton.Click += new System.EventHandler(this.oneButton_Click);
            // 
            // threeButton
            // 
            this.threeButton.Location = new System.Drawing.Point(1280, 159);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(237, 129);
            this.threeButton.TabIndex = 11;
            this.threeButton.Text = "3";
            this.threeButton.UseVisualStyleBackColor = true;
            this.threeButton.Click += new System.EventHandler(this.threeButton_Click);
            // 
            // twoButton
            // 
            this.twoButton.Location = new System.Drawing.Point(1029, 159);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(237, 129);
            this.twoButton.TabIndex = 10;
            this.twoButton.Text = "2";
            this.twoButton.UseVisualStyleBackColor = true;
            this.twoButton.Click += new System.EventHandler(this.twoButton_Click);
            // 
            // sevenButton
            // 
            this.sevenButton.Location = new System.Drawing.Point(1280, 454);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(237, 129);
            this.sevenButton.TabIndex = 15;
            this.sevenButton.Text = "7";
            this.sevenButton.UseVisualStyleBackColor = true;
            this.sevenButton.Click += new System.EventHandler(this.sevenButton_Click);
            // 
            // sixButton
            // 
            this.sixButton.Location = new System.Drawing.Point(1029, 454);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(237, 129);
            this.sixButton.TabIndex = 14;
            this.sixButton.Text = "6";
            this.sixButton.UseVisualStyleBackColor = true;
            this.sixButton.Click += new System.EventHandler(this.sixButton_Click);
            // 
            // fiveButton
            // 
            this.fiveButton.Location = new System.Drawing.Point(1280, 309);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(237, 129);
            this.fiveButton.TabIndex = 13;
            this.fiveButton.Text = "5";
            this.fiveButton.UseVisualStyleBackColor = true;
            this.fiveButton.Click += new System.EventHandler(this.fiveButton_Click);
            // 
            // fourButton
            // 
            this.fourButton.Location = new System.Drawing.Point(1029, 309);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(237, 129);
            this.fourButton.TabIndex = 12;
            this.fourButton.Text = "4";
            this.fourButton.UseVisualStyleBackColor = true;
            this.fourButton.Click += new System.EventHandler(this.fourButton_Click);
            // 
            // nineButton
            // 
            this.nineButton.Location = new System.Drawing.Point(1280, 600);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(237, 129);
            this.nineButton.TabIndex = 17;
            this.nineButton.Text = "9";
            this.nineButton.UseVisualStyleBackColor = true;
            this.nineButton.Click += new System.EventHandler(this.nineButton_Click);
            // 
            // eightButton
            // 
            this.eightButton.Location = new System.Drawing.Point(1029, 600);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(237, 129);
            this.eightButton.TabIndex = 16;
            this.eightButton.Text = "8";
            this.eightButton.UseVisualStyleBackColor = true;
            this.eightButton.Click += new System.EventHandler(this.eightButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(1280, 773);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(237, 121);
            this.exitButton.TabIndex = 19;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(1029, 773);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(237, 121);
            this.resetButton.TabIndex = 18;
            this.resetButton.Text = "&Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(1581, 931);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.nineButton);
            this.Controls.Add(this.eightButton);
            this.Controls.Add(this.sevenButton);
            this.Controls.Add(this.sixButton);
            this.Controls.Add(this.fiveButton);
            this.Controls.Add(this.fourButton);
            this.Controls.Add(this.threeButton);
            this.Controls.Add(this.twoButton);
            this.Controls.Add(this.oneButton);
            this.Controls.Add(this.zeroButton);
            this.Controls.Add(this.topLeftLabel);
            this.Controls.Add(this.botLeftLabel);
            this.Controls.Add(this.botRightLabel);
            this.Controls.Add(this.midLabel);
            this.Controls.Add(this.botLabel);
            this.Controls.Add(this.topRightLabel);
            this.Controls.Add(this.topLabel);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.Text = "MyClock App";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label topLabel;
        private System.Windows.Forms.Label topRightLabel;
        private System.Windows.Forms.Label botLabel;
        private System.Windows.Forms.Label midLabel;
        private System.Windows.Forms.Label botRightLabel;
        private System.Windows.Forms.Label botLeftLabel;
        private System.Windows.Forms.Label topLeftLabel;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button resetButton;
    }
}

